import 'package:flutter/foundation.dart';

class UserPrefs {
  bool diabetes;
  bool gluten;
  bool peanut;
  UserPrefs({this.diabetes = false, this.gluten = false, this.peanut = false});

  UserPrefs copyWith({bool? diabetes, bool? gluten, bool? peanut}) => UserPrefs(
    diabetes: diabetes ?? this.diabetes,
    gluten: gluten ?? this.gluten,
    peanut: peanut ?? this.peanut,
  );
}

class AppState {
  AppState._();
  static final AppState I = AppState._();

  /// Sağlık tercihleri
  final ValueNotifier<UserPrefs> prefs = ValueNotifier(UserPrefs());
}
