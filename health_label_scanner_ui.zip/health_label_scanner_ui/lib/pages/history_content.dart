import 'package:flutter/material.dart';
import '../repository/history_repository.dart';
import '../models/history_item.dart';
import 'history_detail_page.dart';

class HistoryContent extends StatefulWidget {
  const HistoryContent({super.key});

  @override
  State<HistoryContent> createState() => _HistoryContentState();
}

class _HistoryContentState extends State<HistoryContent> {
  final _searchCtrl = TextEditingController();
  bool _onlyRisky = false;

  List<HistoryItem> _filter(List<HistoryItem> src) {
    final q = _searchCtrl.text.trim().toLowerCase();
    var list = src;
    if (q.isNotEmpty) {
      list = list.where((e) =>
          e.name.toLowerCase().contains(q) ||
          e.ocrText.toLowerCase().contains(q)).toList();
    }
    if (_onlyRisky) {
      list = list.where((e) => e.riskLevel == RiskLevel.risky).toList();
    }
    return list.reversed.toList();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    Color levelColor(RiskLevel l) {
      switch (l) {
        case RiskLevel.safe: return Colors.green;
        case RiskLevel.attention: return Colors.orange;
        case RiskLevel.risky: return Colors.red;
      }
    }

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    decoration: const InputDecoration(
                      hintText: 'Ara...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  children: [
                    const Text('Sadece riskli'),
                    Switch(
                      value: _onlyRisky,
                      onChanged: (v) => setState(() => _onlyRisky = v),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ValueListenableBuilder<List<HistoryItem>>(
                valueListenable: HistoryRepository.I.items,
                builder: (context, items, _) {
                  final data = _filter(items);
                  if (data.isEmpty) {
                    return const Center(child: Text('Kayıt yok'));
                  }
                  return ListView.separated(
                    itemCount: data.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final it = data[i];
                      return ListTile(
                        tileColor: cs.surfaceVariant,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        leading: CircleAvatar(
                          backgroundColor: levelColor(it.riskLevel).withOpacity(.15),
                          child: Icon(Icons.inventory_2, color: levelColor(it.riskLevel)),
                        ),
                        title: Text(it.name.isEmpty ? 'Product' : it.name),
                        subtitle: Text('${it.date}'),
                        trailing: Icon(Icons.chevron_right, color: cs.onSurfaceVariant),
                        onTap: () => Navigator.pushNamed(context, HistoryDetailPage.route, arguments: it),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
