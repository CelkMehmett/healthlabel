import 'package:flutter/material.dart';
import '../services/analysis_service.dart';
import '../repository/history_repository.dart';
import '../models/history_item.dart';

class AnalysisArgs {
  final String? imagePath;
  final String ocrText;
  AnalysisArgs({required this.imagePath, required this.ocrText});
}

class AnalysisPage extends StatelessWidget {
  static const route = '/analysis';
  final AnalysisArgs? args;
  const AnalysisPage({super.key, this.args});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final text = args?.ocrText ?? '';
    final result = AnalysisService().analyze(text);

    Widget buildChip(String s, Color bg, Color fg) => Padding(
      padding: const EdgeInsets.only(right: 8, bottom: 8),
      child: Chip(label: Text(s), backgroundColor: bg, labelStyle: TextStyle(color: fg)),
    );

    void save() {
      final item = HistoryItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: result.productName,
        date: DateTime.now(),
        riskLevel: result.overall,
        ocrText: text,
        imagePath: args?.imagePath,
      );
      HistoryRepository.I.add(item);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Geçmişe eklendi')));
      Navigator.pop(context);
    }

    Color levelColor(RiskLevel l) {
      switch (l) {
        case RiskLevel.safe: return Colors.green;
        case RiskLevel.attention: return Colors.orange;
        case RiskLevel.risky: return Colors.red;
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Analiz Sonucu')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            height: 160,
            decoration: BoxDecoration(
              color: cs.surfaceVariant,
              borderRadius: BorderRadius.circular(16),
              image: args?.imagePath != null
                  ? DecorationImage(image: AssetImage(args!.imagePath!), fit: BoxFit.cover)
                  : null,
            ),
            child: args?.imagePath == null
                ? const Center(child: Text('Ürün görseli (placeholder)'))
                : null,
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SelectableText(text.isEmpty ? 'OCR metni bulunamadı' : text),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Text('Genel Durum: ', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(width: 6),
              Chip(
                label: Text(result.overall.name.toUpperCase()),
                backgroundColor: levelColor(result.overall).withOpacity(.15),
                labelStyle: TextStyle(color: levelColor(result.overall), fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text('Risk Analizi', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(
            children: [
              ...result.safe.map((e) => buildChip(e, Colors.green.withOpacity(.15), Colors.green)),
              ...result.attention.map((e) => buildChip(e, Colors.orange.withOpacity(.15), Colors.orange)),
              ...result.risky.map((e) => buildChip(e, Colors.red.withOpacity(.15), Colors.red)),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(child: OutlinedButton(onPressed: () {/* TODO: paylaş */}, child: const Text('Paylaş'))),
              const SizedBox(width: 12),
              Expanded(child: FilledButton(onPressed: save, child: const Text('Kaydet ve Geçmişe Ekle'))),
            ],
          ),
        ],
      ),
    );
  }
}
