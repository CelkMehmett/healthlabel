import 'package:flutter/material.dart';
import '../state/app_state.dart';

class ProfileContent extends StatefulWidget {
  final String lang;
  const ProfileContent({super.key, required this.lang});

  @override
  State<ProfileContent> createState() => _ProfileContentState();
}

class _ProfileContentState extends State<ProfileContent> {
  late bool diabetes;
  late bool gluten;
  late bool peanut;

  @override
  void initState() {
    super.initState();
    final p = AppState.I.prefs.value;
    diabetes = p.diabetes;
    gluten = p.gluten;
    peanut = p.peanut;
  }

  void _save() {
    AppState.I.prefs.value = AppState.I.prefs.value.copyWith(
      diabetes: diabetes,
      gluten: gluten,
      peanut: peanut,
    );
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tercihler kaydedildi')));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    String t(String tr, String en) => widget.lang == 'tr' ? tr : en;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: Column(
              children: [
                CircleAvatar(radius: 36, backgroundColor: cs.primaryContainer, child: const Icon(Icons.person, size: 36)),
                const SizedBox(height: 8),
                Text('Kullanıcı', style: Theme.of(context).textTheme.titleLarge),
                Text('Sağlık tercihleri', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SwitchListTile(
            title: Text(t('Diyabet', 'Diabetes')),
            value: diabetes,
            onChanged: (v) => setState(() => diabetes = v),
          ),
          SwitchListTile(
            title: Text(t('Gluten Hassasiyeti', 'Gluten Intolerance')),
            value: gluten,
            onChanged: (v) => setState(() => gluten = v),
          ),
          SwitchListTile(
            title: Text(t('Fıstık Alerjisi', 'Peanut Allergy')),
            value: peanut,
            onChanged: (v) => setState(() => peanut = v),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t('Son 30 analiz özeti', 'Last 30 scans summary'), style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 10),
                  const LinearProgressIndicator(value: 0.65), // demo
                  const SizedBox(height: 4),
                  Text(t('%65 güvenli ürün', '65% safe products'), style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: Text(t('Kaydet', 'Save'))),
        ],
      ),
    );
  }
}
