import 'package:flutter/material.dart';
import '../services/ocr_service.dart';
import 'analysis_page.dart';

class ScanPage extends StatefulWidget {
  static const route = '/scan';
  const ScanPage({super.key});

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  bool _busy = false;

  Future<void> _takePhoto() async {
    setState(() => _busy = true);
    // TODO: Kamera entegrasyonu ile fotoğraf çek
    // final imagePath = ...
    final ocrText = await OcrService().extractText();
    if (!mounted) return;
    setState(() => _busy = false);

    Navigator.pushNamed(
      context,
      AnalysisPage.route,
      arguments: AnalysisArgs(
        imagePath: null, // imagePath ekleyebilirsin
        ocrText: ocrText,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Tara')),
      body: Column(
        children: [
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cs.surfaceVariant,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Center(child: Text('Kamera Önizleme (placeholder)')),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _busy ? null : () => Navigator.pop(context),
                    child: const Text('İptal'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _busy ? null : _takePhoto,
                    icon: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.camera_alt),
                    label: const Text('Fotoğraf Çek'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
