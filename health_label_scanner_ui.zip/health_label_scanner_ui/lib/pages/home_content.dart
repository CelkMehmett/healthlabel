import 'package:flutter/material.dart';
import 'scan_page.dart';

class HomeContent extends StatelessWidget {
  final String lang;
  const HomeContent({super.key, required this.lang});

  String t(String tr, String en) => lang == 'tr' ? tr : en;

  void _goScan(BuildContext context) {
    Navigator.pushNamed(context, ScanPage.route);
  }

  void _pickFromGallery(BuildContext context) {
    // TODO: Galeri entegrasyonu + OCR
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(t("Galeriden seçim (placeholder)", "Pick from gallery (placeholder)"))),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Stack(
      children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFe8f5e9), Color(0xFFa8e063), Color(0xFF56ab2f)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              image: const DecorationImage(
                image: AssetImage('assets/bg_pattern.png'),
                fit: BoxFit.cover,
                opacity: 0.15,
              ),
            ),
          ),
        ),
        SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: FractionallySizedBox(
                widthFactor: 0.92,
                child: Card(
                  elevation: 8,
                  shadowColor: cs.primary.withOpacity(0.25),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          t("Etiketinizi Tarayın", "Scan Your Label"),
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.w700,
                                color: cs.onSurface,
                              ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          t("Etiketi tarayın, sağlığınızı bilin!", "Scan the label, know your health!"),
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: cs.onSurfaceVariant,
                              ),
                        ),
                        const SizedBox(height: 28),
                        ElevatedButton.icon(
                          onPressed: () => _goScan(context),
                          icon: const Icon(Icons.camera_alt, size: 26),
                          label: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: Text("Tara (Kamera)", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                          ),
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size.fromHeight(56),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                            elevation: 3,
                          ),
                        ),
                        const SizedBox(height: 14),
                        FilledButton.tonalIcon(
                          onPressed: () => _pickFromGallery(context),
                          icon: const Icon(Icons.photo_library_outlined, size: 24),
                          label: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: Text("Galeriden Seç", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                          ),
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(56),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                            elevation: 1,
                          ),
                        ),
                        const SizedBox(height: 22),
                        Container(
                          decoration: BoxDecoration(
                            color: cs.secondaryContainer.withOpacity(0.35),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: cs.secondaryContainer, width: 1),
                          ),
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Icon(Icons.info_outline, color: cs.secondary, size: 24),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  t(
                                    "Analiz, kişisel sağlık tercihlerinize göre yapılır.",
                                    "Analysis is tailored to your health preferences.",
                                  ),
                                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                        color: cs.onSecondaryContainer,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
