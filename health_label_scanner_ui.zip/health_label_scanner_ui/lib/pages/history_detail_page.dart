import 'package:flutter/material.dart';
import '../models/history_item.dart';
import '../repository/history_repository.dart';

class HistoryDetailPage extends StatelessWidget {
  static const route = '/historyDetail';
  final HistoryItem item;
  const HistoryDetailPage({super.key, required this.item});

  Color _level(RiskLevel l) {
    switch (l) {
      case RiskLevel.safe: return Colors.green;
      case RiskLevel.attention: return Colors.orange;
      case RiskLevel.risky: return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Geçmiş Detayı')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            height: 160,
            decoration: BoxDecoration(
              color: cs.surfaceVariant,
              borderRadius: BorderRadius.circular(16),
              image: item.imagePath != null
                  ? DecorationImage(image: AssetImage(item.imagePath!), fit: BoxFit.cover)
                  : null,
            ),
            child: item.imagePath == null
                ? const Center(child: Text('Görsel yok'))
                : null,
          ),
          const SizedBox(height: 16),
          Text(item.name, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(item.date.toString(), style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Genel Durum: '),
              const SizedBox(width: 6),
              Chip(
                label: Text(item.riskLevel.name.toUpperCase()),
                backgroundColor: _level(item.riskLevel).withOpacity(.15),
                labelStyle: TextStyle(color: _level(item.riskLevel), fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SelectableText(item.ocrText),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: OutlinedButton(onPressed: () {/* TODO: paylaş */}, child: const Text('Paylaş'))),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Silinsin mi?'),
                        content: const Text('Bu kaydı silmek istediğine emin misin?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
                          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil')),
                        ],
                      ),
                    );
                    if (ok == true) {
                      HistoryRepository.I.remove(item.id);
                      if (context.mounted) Navigator.pop(context);
                    }
                  },
                  child: const Text('Sil'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
