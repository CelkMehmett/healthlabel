import 'package:flutter/material.dart';
import '../repository/history_repository.dart';

class SettingsContent extends StatefulWidget {
  const SettingsContent({super.key});

  @override
  State<SettingsContent> createState() => _SettingsContentState();
}

class _SettingsContentState extends State<SettingsContent> {
  String _lang = 'TR';
  bool _dark = false;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Ayarlar', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Row(
            children: [
              const Text('Dil:   '),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: _lang,
                items: const [
                  DropdownMenuItem(value: 'TR', child: Text('Türkçe')),
                  DropdownMenuItem(value: 'EN', child: Text('English')),
                ],
                onChanged: (v) => setState(() => _lang = v ?? 'TR'),
              ),
            ],
          ),
          SwitchListTile(
            title: const Text('Koyu Tema'),
            value: _dark,
            onChanged: (v) => setState(() => _dark = v),
          ),
          const SizedBox(height: 8),
          ListTile(
            leading: const Icon(Icons.lock_outline),
            title: const Text('Gizlilik'),
            subtitle: Text('Tüm veriler yalnızca cihazda saklanır.', style: TextStyle(color: cs.onSurfaceVariant)),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {/* TODO: dışa aktar */},
                  child: const Text('Verileri dışa aktar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: () {
                    HistoryRepository.I.clear();
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tüm geçmiş silindi')));
                  },
                  child: const Text('Tüm verileri sil'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
