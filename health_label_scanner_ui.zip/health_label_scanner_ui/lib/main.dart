import 'package:flutter/material.dart';

import 'pages/main_shell.dart';
import 'pages/scan_page.dart';
import 'pages/analysis_page.dart';
import 'pages/history_detail_page.dart';
import 'models/history_item.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Health Label Scanner',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2E7D32),
        brightness: Brightness.light,
      ),
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case ScanPage.route:
            return MaterialPageRoute(builder: (_) => const ScanPage());
          case AnalysisPage.route:
            final args = settings.arguments as AnalysisArgs?;
            return MaterialPageRoute(builder: (_) => AnalysisPage(args: args));
          case HistoryDetailPage.route:
            final item = settings.arguments as HistoryItem;
            return MaterialPageRoute(builder: (_) => HistoryDetailPage(item: item));
          default:
            return MaterialPageRoute(builder: (_) => const MainShell(lang: 'tr'));
        }
      },
      home: const MainShell(lang: 'tr'),
    );
  }
}
