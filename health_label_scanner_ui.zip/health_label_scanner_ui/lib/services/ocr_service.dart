import 'dart:async';

class OcrService {
  Future<String> extractText(/* image param */) async {
    // TODO: Gerçek OCR entegrasyonu
    await Future.delayed(const Duration(milliseconds: 500));
    // Demo metni
    return "Product: Choco Bar\nIngredients: sugar, cocoa, milk powder, emulsifier E322, gluten\nNet 50g";
  }
}
