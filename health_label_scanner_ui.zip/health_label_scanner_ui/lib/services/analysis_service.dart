import '../models/history_item.dart';
import '../state/app_state.dart';

class AnalysisResult {
  final List<String> safe;
  final List<String> attention;
  final List<String> risky;
  final RiskLevel overall;
  final String productName;

  AnalysisResult({
    required this.safe,
    required this.attention,
    required this.risky,
    required this.overall,
    required this.productName,
  });
}

class AnalysisService {
  AnalysisResult analyze(String ocrText) {
    final prefs = AppState.I.prefs.value;

    final text = ocrText.toLowerCase();
    final risky = <String>[];
    final attention = <String>[];
    final safe = <String>[];

    // Basit kurallar (örnek)
    if (prefs.gluten && text.contains('gluten')) risky.add('Gluten içerir');
    if (prefs.peanut && (text.contains('peanut') || text.contains('fıstık'))) risky.add('Fıstık alerjeni içerebilir');
    if (prefs.diabetes && text.contains('sugar')) attention.add('Şeker içerir (dikkat)');
    if (text.contains('emulsifier') || text.contains('e')) attention.add('Katkı maddeleri mevcut');
    if (text.contains('low sugar') || text.contains('unsweetened')) safe.add('Düşük şeker');

    RiskLevel overall = RiskLevel.safe;
    if (risky.isNotEmpty) {
      overall = RiskLevel.risky;
    } else if (attention.isNotEmpty) {
      overall = RiskLevel.attention;
    }

    // Ürün adı yakalama (çok basit)
    final name = _extractName(ocrText);

    return AnalysisResult(
      safe: safe,
      attention: attention,
      risky: risky,
      overall: overall,
      productName: name,
    );
  }

  String _extractName(String text) {
    final lines = text.split('\n');
    for (final l in lines) {
      if (l.toLowerCase().startsWith('product:')) {
        return l.split(':').last.trim();
      }
    }
    // Yoksa ilk satırı veya fallback
    return lines.isNotEmpty ? lines.first.trim() : 'Product';
  }
}
