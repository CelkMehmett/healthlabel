import 'package:flutter/foundation.dart';
import '../models/history_item.dart';

class HistoryRepository {
  HistoryRepository._();
  static final HistoryRepository I = HistoryRepository._();

  final ValueNotifier<List<HistoryItem>> items = ValueNotifier<List<HistoryItem>>([]);

  void add(HistoryItem item) {
    items.value = [...items.value, item];
  }

  void remove(String id) {
    items.value = items.value.where((e) => e.id != id).toList();
  }

  void clear() {
    items.value = [];
  }
}
