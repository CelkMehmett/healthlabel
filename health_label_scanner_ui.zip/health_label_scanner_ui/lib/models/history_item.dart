enum RiskLevel { safe, attention, risky }

class HistoryItem {
  final String id;
  final String name;
  final DateTime date;
  final RiskLevel riskLevel;
  final String ocrText;
  final String? imagePath; // (isteğe bağlı) dosya yolu

  HistoryItem({
    required this.id,
    required this.name,
    required this.date,
    required this.riskLevel,
    required this.ocrText,
    this.imagePath,
  });
}
